/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excepciones;

/**
 * Excepción personalizada para manejar errores relacionados con la lógica de
 * negocio. Extiende de la clase {@link Exception} y proporciona dos
 * constructores para especificar el mensaje de error y la causa.
 *
 * @author Alejandra García Preciado
 */
public class NegocioException extends Exception {

    /**
     * Constructor que crea una nueva instancia de {@code NegocioException} con
     * el mensaje de error especificado.
     *
     * @param message El mensaje de error que describe el motivo de la
     * excepción.
     */
    public NegocioException(String message) {
        super(message);
    }

    /**
     * Constructor que crea una nueva instancia de {@code NegocioException} con
     * el mensaje de error especificado y la causa de la excepción.
     *
     * @param message El mensaje de error que describe el motivo de la
     * excepción.
     * @param cause La causa de la excepción (una excepción anterior que causó
     * esta).
     */
    public NegocioException(String message, Throwable cause) {
        super(message, cause);
    }

}
