/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configuracion;

import BO.CitaBO;
import BO.ConsultaBO;
import BO.MedicoBO;
import BO.PacienteBO;
import BO.UsuarioBO;
import conexion.Conexion;
import conexion.IConexion;

/**
 * Clase encargada de la inyección de dependencias, proporcionando instancias de
 * los objetos de negocio ({@link CitaBO}, {@link ConsultaBO}, {@link MedicoBO},
 * {@link PacienteBO}, {@link UsuarioBO}) con sus dependencias configuradas,
 * como la conexión a la base de datos.
 *
 * <p>
 * Utiliza la implementación de la interfaz {@link IConexion} para inyectar la
 * dependencia de la conexión a la base de datos a las clases de negocio
 * correspondientes.</p>
 *
 * @author Alejandra García Preciado
 */
public class DependencyInjector {

    /**
     * Crea una instancia de {@link CitaBO} con su dependencia configurada.
     *
     * @return Una instancia de {@link CitaBO} completamente configurada con la
     * conexión.
     */
    public static CitaBO crearCitaBO() {
        // Crear una instancia de la conexión a la base de datos, utilizando la implementación de IConexion
        IConexion conexion = new Conexion();

        // Inyectar la dependencia de conexión a la instancia 
        CitaBO citaBO = new CitaBO(conexion);

        // Retornar la instancia completamente configurada
        return citaBO;
    }

    /**
     * Crea una instancia de {@link ConsultaBO} con su dependencia configurada.
     *
     * @return Una instancia de {@link ConsultaBO} completamente configurada con
     * la conexión.
     */
    public static ConsultaBO crearConsultaBO() {
        // Crear una instancia de la conexión a la base de datos, utilizando la implementación de IConexion
        IConexion conexion = new Conexion();

        // Inyectar la dependencia de conexión a la instancia 
        ConsultaBO consultaBO = new ConsultaBO(conexion);

        // Retornar la instancia completamente configurada
        return consultaBO;
    }

    /**
     * Crea una instancia de {@link PacienteBO} con su dependencia configurada.
     *
     * @return Una instancia de {@link PacienteBO} completamente configurada con
     * la conexión.
     */
    public static PacienteBO crearPacienteBO() {
        // Crear una instancia de la conexión a la base de datos, utilizando la implementación de IConexion
        IConexion conexion = new Conexion();

        // Inyectar la dependencia de conexión a la instancia 
        PacienteBO pacienteBO = new PacienteBO(conexion);

        // Retornar la instancia completamente configurada
        return pacienteBO;
    }

    /**
     * Crea una instancia de {@link UsuarioBO} con su dependencia configurada.
     *
     * @return Una instancia de {@link UsuarioBO} completamente configurada con
     * la conexión.
     */
    public static UsuarioBO crearUsuarioBO() {
        // Crear una instancia de la conexión a la base de datos, utilizando la implementación de IConexion
        IConexion conexion = new Conexion();

        // Inyectar la dependencia de conexión a la instancia 
        UsuarioBO usuarioBO = new UsuarioBO(conexion);

        // Retornar la instancia completamente configurada
        return usuarioBO;
    }

    /**
     * Crea una instancia de {@link MedicoBO} con su dependencia configurada.
     *
     * @return Una instancia de {@link MedicoBO} completamente configurada con
     * la conexión.
     */
    public static MedicoBO crearMedicoBO() {
        // Crear una instancia de la conexión a la base de datos, utilizando la implementación de IConexion
        IConexion conexion = new Conexion();

        // Inyectar la dependencia de conexión a la instancia 
        MedicoBO medicoBO = new MedicoBO(conexion);

        // Retornar la instancia completamente configurada
        return medicoBO;
    }

}
