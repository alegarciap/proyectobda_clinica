/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 * Clase que representa un Usuario con sus credenciales. Esta clase contiene
 * datos básicos de un usuario como su ID, nombre y contraseña.
 *
 * @author Alejandra García Preciado
 */
public class UsuarioDTO {

    /**
     * El ID único del usuario.
     */
    private int id_usuario;

    /**
     * El nombre del usuario.
     */
    private String nombre;

    /**
     * La contraseña del usuario.
     */
    private String contrasenia;

    /**
     * Constructor vacío de la clase UsuarioDTO.
     */
    public UsuarioDTO() {
    }

    /**
     * Constructor de la clase UsuarioDTO con todos los atributos.
     *
     * @param id_usuario El ID del usuario.
     * @param nombre El nombre del usuario.
     * @param contrasenia La contraseña del usuario.
     */
    public UsuarioDTO(int id_usuario, String nombre, String contrasenia) {
        this.id_usuario = id_usuario;
        this.nombre = nombre;
        this.contrasenia = contrasenia;
    }

    /**
     * Constructor de la clase UsuarioDTO sin el atributo id_usuario.
     *
     * @param nombre El nombre del usuario.
     * @param contrasenia La contraseña del usuario.
     */
    public UsuarioDTO(String nombre, String contrasenia) {
        this.nombre = nombre;
        this.contrasenia = contrasenia;
    }

    /**
     * Obtiene el ID del usuario.
     *
     * @return El ID del usuario.
     */
    public int getId_usuario() {
        return id_usuario;
    }

    /**
     * Establece el ID del usuario.
     *
     * @param id_usuario El ID del usuario.
     */
    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    /**
     * Obtiene el nombre del usuario.
     *
     * @return El nombre del usuario.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del usuario.
     *
     * @param nombre El nombre del usuario.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la contraseña del usuario.
     *
     * @return La contraseña del usuario.
     */
    public String getContrasenia() {
        return contrasenia;
    }

    /**
     * Establece la contraseña del usuario.
     *
     * @param contrasenia La contraseña del usuario.
     */
    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    /**
     * Método que devuelve una representación en cadena de caracteres del objeto
     * UsuarioDTO.
     *
     * @return Una cadena de texto representando los datos del usuario.
     */
    @Override
    public String toString() {
        return "UsuarioDTO{" + "id_usuario=" + id_usuario + ", nombre=" + nombre + ", contrasenia=" + contrasenia + '}';
    }

}
