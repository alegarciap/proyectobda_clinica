/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.sql.Timestamp;

/**
 * La clase {@code ConsultaDTO} representa una consulta médica, incluyendo
 * detalles como el identificador de la consulta, la fecha y hora, el
 * diagnóstico, el tratamiento, las observaciones y la cita asociada.
 * <p>
 * Esta clase es un DTO (Data Transfer Object) utilizado para transferir los
 * datos de una consulta médica entre las capas de la aplicación.
 * </p>
 *
 * @author Alejandra García Preciado
 */
public class ConsultaDTO {

    /**
     * El identificador único de la consulta.
     */
    private int id_consulta;

    /**
     * La fecha y hora de la consulta médica.
     */
    private Timestamp fecha_hora;

    /**
     * El diagnóstico realizado durante la consulta.
     */
    private String diagnostico;

    /**
     * El tratamiento prescrito durante la consulta.
     */
    private String tratamiento;

    /**
     * Las observaciones adicionales sobre la consulta.
     */
    private String observaciones;

    /**
     * La cita asociada con la consulta médica.
     */
    private CitaDTO cita;

    /**
     * Constructor por defecto de la clase {@code ConsultaDTO}.
     */
    public ConsultaDTO() {
    }

    /**
     * Constructor de la clase {@code ConsultaDTO} que permite crear una
     * instancia con todos los atributos.
     *
     * @param id_consulta El identificador único de la consulta.
     * @param fecha_hora La fecha y hora de la consulta.
     * @param diagnostico El diagnóstico realizado durante la consulta.
     * @param tratamiento El tratamiento prescrito durante la consulta.
     * @param observaciones Las observaciones adicionales de la consulta.
     * @param cita La cita asociada con la consulta.
     */
    public ConsultaDTO(int id_consulta, Timestamp fecha_hora, String diagnostico, String tratamiento, String observaciones, CitaDTO cita) {
        this.id_consulta = id_consulta;
        this.fecha_hora = fecha_hora;
        this.diagnostico = diagnostico;
        this.tratamiento = tratamiento;
        this.observaciones = observaciones;
        this.cita = cita;
    }

    /**
     * Constructor de la clase {@code ConsultaDTO} que permite crear una
     * instancia sin el identificador de la consulta.
     *
     * @param fecha_hora La fecha y hora de la consulta.
     * @param diagnostico El diagnóstico realizado durante la consulta.
     * @param tratamiento El tratamiento prescrito durante la consulta.
     * @param observaciones Las observaciones adicionales de la consulta.
     * @param cita La cita asociada con la consulta.
     */
    public ConsultaDTO(Timestamp fecha_hora, String diagnostico, String tratamiento, String observaciones, CitaDTO cita) {
        this.fecha_hora = fecha_hora;
        this.diagnostico = diagnostico;
        this.tratamiento = tratamiento;
        this.observaciones = observaciones;
        this.cita = cita;
    }

    /**
     * Obtiene el identificador único de la consulta.
     *
     * @return El identificador único de la consulta.
     */
    public int getId_consulta() {
        return id_consulta;
    }

    /**
     * Establece el identificador único de la consulta.
     *
     * @param id_consulta El identificador único de la consulta.
     */
    public void setId_consulta(int id_consulta) {
        this.id_consulta = id_consulta;
    }

    /**
     * Obtiene la fecha y hora de la consulta.
     *
     * @return La fecha y hora programada de la consulta.
     */
    public Timestamp getFecha_hora() {
        return fecha_hora;
    }

    /**
     * Establece la fecha y hora de la consulta.
     *
     * @param fecha_hora La fecha y hora programada de la consulta.
     */
    public void setFecha_hora(Timestamp fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    /**
     * Obtiene el diagnóstico realizado durante la consulta.
     *
     * @return El diagnóstico de la consulta.
     */
    public String getDiagnostico() {
        return diagnostico;
    }

    /**
     * Establece el diagnóstico realizado durante la consulta.
     *
     * @param diagnostico El diagnóstico de la consulta.
     */
    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    /**
     * Obtiene el tratamiento prescrito durante la consulta.
     *
     * @return El tratamiento prescrito de la consulta.
     */
    public String getTratamiento() {
        return tratamiento;
    }

    /**
     * Establece el tratamiento prescrito durante la consulta.
     *
     * @param tratamiento El tratamiento de la consulta.
     */
    public void setTratamiento(String tratamiento) {
        this.tratamiento = tratamiento;
    }

    /**
     * Obtiene las observaciones adicionales sobre la consulta.
     *
     * @return Las observaciones de la consulta.
     */
    public String getObservaciones() {
        return observaciones;
    }

    /**
     * Establece las observaciones adicionales sobre la consulta.
     *
     * @param observaciones Las observaciones de la consulta.
     */
    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    /**
     * Obtiene la cita asociada con la consulta médica.
     *
     * @return La cita asociada con la consulta.
     */
    public CitaDTO getCita() {
        return cita;
    }

    /**
     * Establece la cita asociada con la consulta médica.
     *
     * @param cita La cita asociada con la consulta.
     */
    public void setCita(CitaDTO cita) {
        this.cita = cita;
    }

    /**
     * Retorna una representación en formato de cadena de la consulta.
     *
     * @return Una cadena que representa la consulta, incluyendo el
     * identificador, la fecha, el diagnóstico, el tratamiento, las
     * observaciones y la cita asociada.
     */
    @Override
    public String toString() {
        return "ConsultasDTO{" + "id_consulta=" + id_consulta + ", fecha_hora=" + fecha_hora + ", diagnostico=" + diagnostico + ", tratamiento=" + tratamiento + ", observaciones=" + observaciones + ", cita=" + cita + '}';
    }

}
