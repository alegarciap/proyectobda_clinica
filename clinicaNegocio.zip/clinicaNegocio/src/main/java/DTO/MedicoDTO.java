/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 * La clase {@code MedicoDTO} representa los datos de un médico, incluyendo su
 * identificación, nombre, apellidos, cédula, especialidad, estado y el usuario
 * asociado a dicho médico.
 * <p>
 * Esta clase es un DTO (Data Transfer Object) utilizado para transferir los
 * datos de un médico entre las capas de la aplicación.
 * </p>
 *
 * @author Alejandra García Preciado
 */
public class MedicoDTO {

    /**
     * El identificador único del médico.
     */
    private int id_medico;

    /**
     * El nombre del médico.
     */
    private String nombre;

    /**
     * El apellido paterno del médico.
     */
    private String apellido_paterno;

    /**
     * El apellido materno del médico.
     */
    private String apellido_materno;

    /**
     * La cédula profesional del médico.
     */
    private String cedula;

    /**
     * La especialidad del médico.
     */
    private String especialidad;

    /**
     * El estado en el que se encuentra el médico (activo, inactivo, etc.).
     */
    private String estado;

    /**
     * El usuario asociado con el médico.
     */
    private UsuarioDTO usuario;

    /**
     * Constructor por defecto de la clase {@code MedicoDTO}.
     */
    public MedicoDTO() {
    }

    /**
     * Constructor de la clase {@code MedicoDTO} que permite crear una instancia
     * con todos los atributos.
     *
     * @param id_medico El identificador único del médico.
     * @param nombre El nombre del médico.
     * @param apellido_paterno El apellido paterno del médico.
     * @param apellido_materno El apellido materno del médico.
     * @param cedula La cédula profesional del médico.
     * @param especialidad La especialidad del médico.
     * @param estado El estado del médico.
     * @param usuario El usuario asociado con el médico.
     */
    public MedicoDTO(int id_medico, String nombre, String apellido_paterno, String apellido_materno, String cedula, String especialidad, String estado, UsuarioDTO usuario) {
        this.id_medico = id_medico;
        this.nombre = nombre;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.cedula = cedula;
        this.especialidad = especialidad;
        this.estado = estado;
        this.usuario = usuario;
    }

    /**
     * Constructor de la clase {@code MedicoDTO} que permite crear una instancia
     * sin el identificador del médico.
     *
     * @param nombre El nombre del médico.
     * @param apellido_paterno El apellido paterno del médico.
     * @param apellido_materno El apellido materno del médico.
     * @param cedula La cédula profesional del médico.
     * @param especialidad La especialidad del médico.
     * @param estado El estado del médico.
     * @param usuario El usuario asociado con el médico.
     */
    public MedicoDTO(String nombre, String apellido_paterno, String apellido_materno, String cedula, String especialidad, String estado, UsuarioDTO usuario) {
        this.nombre = nombre;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.cedula = cedula;
        this.especialidad = especialidad;
        this.estado = estado;
        this.usuario = usuario;
    }

    /**
     * Obtiene el identificador único del médico.
     *
     * @return El identificador único del médico.
     */
    public int getId_medico() {
        return id_medico;
    }

    /**
     * Establece el identificador único del médico.
     *
     * @param id_medico El identificador único del médico.
     */
    public void setId_medico(int id_medico) {
        this.id_medico = id_medico;
    }

    /**
     * Obtiene el nombre del médico.
     *
     * @return El nombre del médico.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del médico.
     *
     * @param nombre El nombre del médico.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el apellido paterno del médico.
     *
     * @return El apellido paterno del médico.
     */
    public String getApellido_paterno() {
        return apellido_paterno;
    }

    /**
     * Establece el apellido paterno del médico.
     *
     * @param apellido_paterno El apellido paterno del médico.
     */
    public void setApellido_paterno(String apellido_paterno) {
        this.apellido_paterno = apellido_paterno;
    }

    /**
     * Obtiene el apellido materno del médico.
     *
     * @return El apellido materno del médico.
     */
    public String getApellido_materno() {
        return apellido_materno;
    }

    /**
     * Establece el apellido materno del médico.
     *
     * @param apellido_materno El apellido materno del médico.
     */
    public void setApellido_materno(String apellido_materno) {
        this.apellido_materno = apellido_materno;
    }

    /**
     * Obtiene la cédula profesional del médico.
     *
     * @return La cédula profesional del médico.
     */
    public String getCedula() {
        return cedula;
    }

    /**
     * Establece la cédula profesional del médico.
     *
     * @param cedula La cédula profesional del médico.
     */
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    /**
     * Obtiene la especialidad del médico.
     *
     * @return La especialidad del médico.
     */
    public String getEspecialidad() {
        return especialidad;
    }

    /**
     * Establece la especialidad del médico.
     *
     * @param especialidad La especialidad del médico.
     */
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    /**
     * Obtiene el estado del médico.
     *
     * @return El estado del médico (activo, inactivo, etc.).
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Establece el estado del médico.
     *
     * @param estado El estado del médico (activo, inactivo, etc.).
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Obtiene el usuario asociado con el médico.
     *
     * @return El usuario asociado con el médico.
     */
    public UsuarioDTO getUsuario() {
        return usuario;
    }

    /**
     * Establece el usuario asociado con el médico.
     *
     * @param usuario El usuario asociado con el médico.
     */
    public void setUsuario(UsuarioDTO usuario) {
        this.usuario = usuario;
    }

    /**
     * Retorna una representación en formato de cadena del médico.
     *
     * @return Una cadena que representa al médico, incluyendo el identificador,
     * el nombre, los apellidos, la cédula, la especialidad, el estado y el
     * usuario.
     */
    @Override
    public String toString() {
        return "MedicoDTO{" + "id_medico=" + id_medico + ", nombre=" + nombre + ", apellido_paterno=" + apellido_paterno + ", apellido_materno=" + apellido_materno + ", cedula=" + cedula + ", especialidad=" + especialidad + ", estado=" + estado + ", usuario=" + usuario + '}';
    }

}
