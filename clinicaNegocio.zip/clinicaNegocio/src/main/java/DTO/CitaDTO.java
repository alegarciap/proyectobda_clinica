/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.sql.Timestamp;

/**
 * La clase {@code CitaDTO} representa una cita médica, incluyendo detalles como
 * el identificador de la cita, la fecha y hora de la cita, el estado de la
 * cita, el folio asociado, el paciente y el médico.
 * <p>
 * Esta clase es un DTO (Data Transfer Object) utilizado para transferir los
 * datos de una cita médica entre las capas de la aplicación.
 * </p>
 *
 * @author Alejandra García Preciado
 */
public class CitaDTO {

    /**
     * El identificador único de la cita.
     */
    private int id_cita;

    /**
     * La fecha y hora programadas de la cita.
     */
    private Timestamp fecha_hora;

    /**
     * El estado de la cita (por ejemplo, confirmada, cancelada, etc.).
     */
    private String estado;

    /**
     * El folio único asociado con la cita.
     */
    private String folio;

    /**
     * El paciente que tiene la cita.
     */
    private PacienteDTO paciente;

    /**
     * El médico asignado a la cita.
     */
    private MedicoDTO medico;

    /**
     * Constructor por defecto de la clase {@code CitaDTO}.
     */
    public CitaDTO() {
    }

    /**
     * Constructor de la clase {@code CitaDTO} que permite crear una instancia
     * con todos los atributos.
     *
     * @param id_cita El identificador único de la cita.
     * @param fecha_hora La fecha y hora de la cita.
     * @param estado El estado de la cita.
     * @param folio El folio único de la cita.
     * @param paciente El paciente asociado con la cita.
     * @param medico El médico asignado a la cita.
     */
    public CitaDTO(int id_cita, Timestamp fecha_hora, String estado, String folio, PacienteDTO paciente, MedicoDTO medico) {
        this.id_cita = id_cita;
        this.fecha_hora = fecha_hora;
        this.estado = estado;
        this.folio = folio;
        this.paciente = paciente;
        this.medico = medico;
    }

    /**
     * Constructor de la clase {@code CitaDTO} que permite crear una instancia
     * sin el identificador de la cita.
     *
     * @param fecha_hora La fecha y hora de la cita.
     * @param estado El estado de la cita.
     * @param folio El folio único de la cita.
     * @param paciente El paciente asociado con la cita.
     * @param medico El médico asignado a la cita.
     */
    public CitaDTO(Timestamp fecha_hora, String estado, String folio, PacienteDTO paciente, MedicoDTO medico) {
        this.fecha_hora = fecha_hora;
        this.estado = estado;
        this.folio = folio;
        this.paciente = paciente;
        this.medico = medico;
    }

    /**
     * Obtiene el identificador único de la cita.
     *
     * @return El identificador único de la cita.
     */
    public int getId_cita() {
        return id_cita;
    }

    /**
     * Establece el identificador único de la cita.
     *
     * @param id_cita El identificador único de la cita.
     */
    public void setId_cita(int id_cita) {
        this.id_cita = id_cita;
    }

    /**
     * Obtiene la fecha y hora de la cita.
     *
     * @return La fecha y hora programada de la cita.
     */
    public Timestamp getFecha_hora() {
        return fecha_hora;
    }

    /**
     * Establece la fecha y hora de la cita.
     *
     * @param fecha_hora La fecha y hora programada de la cita.
     */
    public void setFecha_hora(Timestamp fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    /**
     * Obtiene el estado de la cita.
     *
     * @return El estado de la cita (por ejemplo, confirmada, cancelada, etc.).
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Establece el estado de la cita.
     *
     * @param estado El estado de la cita (por ejemplo, confirmada, cancelada,
     * etc.).
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Obtiene el folio único de la cita.
     *
     * @return El folio único de la cita.
     */
    public String getFolio() {
        return folio;
    }

    /**
     * Establece el folio único de la cita.
     *
     * @param folio El folio único de la cita.
     */
    public void setFolio(String folio) {
        this.folio = folio;
    }

    /**
     * Obtiene el paciente asociado con la cita.
     *
     * @return El paciente de la cita.
     */
    public PacienteDTO getPaciente() {
        return paciente;
    }

    /**
     * Establece el paciente asociado con la cita.
     *
     * @param paciente El paciente de la cita.
     */
    public void setPaciente(PacienteDTO paciente) {
        this.paciente = paciente;
    }

    /**
     * Obtiene el médico asignado a la cita.
     *
     * @return El médico asignado a la cita.
     */
    public MedicoDTO getMedico() {
        return medico;
    }

    /**
     * Establece el médico asignado a la cita.
     *
     * @param medico El médico asignado a la cita.
     */
    public void setMedico(MedicoDTO medico) {
        this.medico = medico;
    }

    /**
     * Retorna una representación en formato de cadena de la cita.
     *
     * @return Una cadena que representa la cita, incluyendo el identificador,
     * la fecha, el estado, el folio, el paciente y el médico.
     */
    @Override
    public String toString() {
        return "CitaDTO{" + "id_cita=" + id_cita + ", fecha_hora=" + fecha_hora + ", estado=" + estado + ", folio=" + folio + ", paciente=" + paciente + ", medico=" + medico + '}';
    }

}
