/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.util.Date;

/**
 * Clase que representa un Paciente con información personal y contacto. Esta
 * clase contiene datos como el nombre, apellidos, dirección, fecha de
 * nacimiento, teléfono, correo y un objeto UsuarioDTO que contiene los datos
 * del usuario asociado al paciente.
 * <p>
 * Esta clase es un DTO (Data Transfer Object) utilizado para transferir los
 * datos de un médico entre las capas de la aplicación.
 * </p>
 *
 * @author Alejandra García Preciado
 */
public class PacienteDTO {

    /**
     * El ID único del paciente.
     */
    private int id_paciente;

    /**
     * El nombre del paciente.
     */
    private String nombre;

    /**
     * El apellido paterno del paciente.
     */
    private String apellido_paterno;

    /**
     * El apellido materno del paciente.
     */
    private String apellido_materno;

    /**
     * La dirección del paciente.
     */
    private String direccion;

    /**
     * La fecha de nacimiento del paciente.
     */
    private Date fecha_nacimiento;

    /**
     * El número de teléfono del paciente.
     */
    private String telefono;

    /**
     * El correo electrónico del paciente.
     */
    private String correo;

    /**
     * El objeto UsuarioDTO asociado al paciente.
     */
    private UsuarioDTO usuario;

    /**
     * Constructor vacío de la clase PacienteDTO.
     */
    public PacienteDTO() {
    }

    /**
     * Constructor de la clase PacienteDTO con todos los atributos.
     *
     * @param id_paciente El ID del paciente.
     * @param nombre El nombre del paciente.
     * @param apellido_paterno El apellido paterno del paciente.
     * @param apellido_materno El apellido materno del paciente.
     * @param direccion La dirección del paciente.
     * @param fecha_nacimiento La fecha de nacimiento del paciente.
     * @param telefono El número de teléfono del paciente.
     * @param correo El correo electrónico del paciente.
     * @param usuario El objeto UsuarioDTO asociado al paciente.
     */
    public PacienteDTO(int id_paciente, String nombre, String apellido_paterno, String apellido_materno, String direccion, Date fecha_nacimiento, String telefono, String correo, UsuarioDTO usuario) {
        this.id_paciente = id_paciente;
        this.nombre = nombre;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.direccion = direccion;
        this.fecha_nacimiento = fecha_nacimiento;
        this.telefono = telefono;
        this.correo = correo;
        this.usuario = usuario;
    }

    /**
     * Constructor de la clase PacienteDTO sin el atributo id_paciente.
     *
     * @param nombre El nombre del paciente.
     * @param apellido_paterno El apellido paterno del paciente.
     * @param apellido_materno El apellido materno del paciente.
     * @param direccion La dirección del paciente.
     * @param fecha_nacimiento La fecha de nacimiento del paciente.
     * @param telefono El número de teléfono del paciente.
     * @param correo El correo electrónico del paciente.
     * @param usuario El objeto UsuarioDTO asociado al paciente.
     */
    public PacienteDTO(String nombre, String apellido_paterno, String apellido_materno, String direccion, Date fecha_nacimiento, String telefono, String correo, UsuarioDTO usuario) {
        this.nombre = nombre;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.direccion = direccion;
        this.fecha_nacimiento = fecha_nacimiento;
        this.telefono = telefono;
        this.correo = correo;
        this.usuario = usuario;
    }

    /**
     * Obtiene el ID del paciente.
     *
     * @return El ID del paciente.
     */
    public int getId_paciente() {
        return id_paciente;
    }

    /**
     * Establece el ID del paciente.
     *
     * @param id_paciente El ID del paciente.
     */
    public void setId_paciente(int id_paciente) {
        this.id_paciente = id_paciente;
    }

    /**
     * Obtiene el nombre del paciente.
     *
     * @return El nombre del paciente.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del paciente.
     *
     * @param nombre El nombre del paciente.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el apellido paterno del paciente.
     *
     * @return El apellido paterno del paciente.
     */
    public String getApellido_paterno() {
        return apellido_paterno;
    }

    /**
     * Establece el apellido paterno del paciente.
     *
     * @param apellido_paterno El apellido paterno del paciente.
     */
    public void setApellido_paterno(String apellido_paterno) {
        this.apellido_paterno = apellido_paterno;
    }

    /**
     * Obtiene el apellido materno del paciente.
     *
     * @return El apellido materno del paciente.
     */
    public String getApellido_materno() {
        return apellido_materno;
    }

    /**
     * Establece el apellido materno del paciente.
     *
     * @param apellido_materno El apellido materno del paciente.
     */
    public void setApellido_materno(String apellido_materno) {
        this.apellido_materno = apellido_materno;
    }

    /**
     * Obtiene la dirección del paciente.
     *
     * @return La dirección del paciente.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Establece la dirección del paciente.
     *
     * @param direccion La dirección del paciente.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Obtiene la fecha de nacimiento del paciente.
     *
     * @return La fecha de nacimiento del paciente.
     */
    public Date getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    /**
     * Establece la fecha de nacimiento del paciente.
     *
     * @param fecha_nacimiento La fecha de nacimiento del paciente.
     */
    public void setFecha_nacimiento(Date fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    /**
     * Obtiene el teléfono del paciente.
     *
     * @return El teléfono del paciente.
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Establece el teléfono del paciente.
     *
     * @param telefono El teléfono del paciente.
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * Obtiene el correo electrónico del paciente.
     *
     * @return El correo electrónico del paciente.
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Establece el correo electrónico del paciente.
     *
     * @param correo El correo electrónico del paciente.
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * Obtiene el objeto UsuarioDTO asociado al paciente.
     *
     * @return El objeto UsuarioDTO asociado al paciente.
     */
    public UsuarioDTO getUsuario() {
        return usuario;
    }

    /**
     * Establece el objeto UsuarioDTO asociado al paciente.
     *
     * @param usuario El objeto UsuarioDTO asociado al paciente.
     */
    public void setUsuario(UsuarioDTO usuario) {
        this.usuario = usuario;
    }

    /**
     * Método que devuelve una representación en cadena de caracteres del objeto
     * PacienteDTO.
     *
     * @return Una cadena de texto representando los datos del paciente.
     */
    @Override
    public String toString() {
        return "PacienteDTO{" + "id_paciente=" + id_paciente + ", nombre=" + nombre + ", apellido_paterno=" + apellido_paterno + ", apellido_materno=" + apellido_materno + ", direccion=" + direccion + ", fecha_nacimiento=" + fecha_nacimiento + ", telefono=" + telefono + ", correo=" + correo + ", usuario=" + usuario + '}';
    }

}
