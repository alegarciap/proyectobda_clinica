/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BO;

import DAO.ConsultaDAO;
import DAO.IConsultaDAO;
import DTO.ConsultaDTO;
import conexion.IConexion;
import entidades.Consulta;
import excepciones.NegocioException;
import excepciones.PersistenciaException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import mapper.Mapper;

/**
 * La clase ConsultaBO es responsable de manejar la lógica de negocio
 * relacionada con las consultas médicas. Utiliza el patrón DAO para interactuar
 * con la base de datos a través de la interfaz IConsultaDAO.
 *
 * Esta clase proporciona métodos para realizar consultas, obtener historial de
 * consultas de un paciente y obtener historial de consultas realizadas por un
 * médico a un paciente específico.
 *
 * @author Alejandra García Preciado
 */
public class ConsultaBO {

    /**
     * Logger utilizado para registrar errores y eventos.
     */
    private static final Logger logger = Logger.getLogger(ConsultaBO.class.getName());

    /**
     * Instancia de la interfaz de acceso a datos de las citas.
     */
    private final IConsultaDAO consultaDAO;

    /**
     * Constructor de la clase ConsultaBO.
     *
     * @param conexion la conexión utilizada para crear la instancia del DAO de
     * consulta.
     */
    public ConsultaBO(IConexion conexion) {
        this.consultaDAO = new ConsultaDAO(conexion);
    }

    /**
     * Realiza una consulta médica y la guarda en la base de datos.
     *
     * @param consultaDTO el objeto de transferencia de datos que contiene la
     * información de la consulta a registrar.
     * @throws NegocioException si ocurre un error relacionado con la lógica de
     * negocio al realizar la consulta.
     */
    public void realizarConsulta(ConsultaDTO consultaDTO) throws NegocioException {
        try {
            consultaDAO.realizarConsulta(Mapper.toEntity(consultaDTO));
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al registrar consulta.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

    /**
     * Obtiene el historial de consultas de un paciente dentro de un rango de
     * fechas y/o especialidad.
     *
     * @param id_paciente el ID del paciente para el cual se obtiene el
     * historial de consultas.
     * @param especialidad la especialidad médica para filtrar las consultas,
     * puede ser nula si no se requiere filtro.
     * @param fecha_inicio la fecha de inicio del rango de búsqueda de las
     * consultas.
     * @param fecha_fin la fecha final del rango de búsqueda de las consultas.
     * @return una lista de objetos ConsultaDTO que representan el historial de
     * consultas del paciente.
     * @throws NegocioException si ocurre un error relacionado con la lógica de
     * negocio.
     */
    public List<ConsultaDTO> obtenerHistorialConsultas(int id_paciente, String especialidad, Timestamp fecha_inicio, Timestamp fecha_fin) throws NegocioException {
        if (id_paciente <= 0) {
            throw new NegocioException("ID de paciente inválido.");
        }
        
        try {
            List<Consulta> historial_consultas = consultaDAO.obtenerHistorialConsultas(id_paciente, especialidad, fecha_inicio, fecha_fin);
            List<ConsultaDTO> consultasDTO = new ArrayList<>();
            for (Consulta consulta : historial_consultas) {
                consultasDTO.add(Mapper.toDTO(consulta));
            }
            return consultasDTO;
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al obtener las consultas.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

    /**
     * Obtiene el historial de consultas realizadas por un médico a un paciente
     * específico.
     *
     * @param id_medico el ID del médico para el cual se obtiene el historial de
     * consultas.
     * @param id_paciente el ID del paciente para el cual se obtiene el
     * historial de consultas realizadas por el médico.
     * @return una lista de objetos ConsultaDTO que representan el historial de
     * consultas realizadas por el médico.
     * @throws NegocioException si ocurre un error relacionado con la lógica de
     * negocio.
     */
    public List<ConsultaDTO> obtenerHistorialConsultasMedicos(int id_medico, int id_paciente) throws NegocioException {
        if (id_medico <= 0) {
            throw new NegocioException("ID médico inválido.");
        }

        if (id_paciente <= 0) {
            throw new NegocioException("ID paciente inválido.");
        }
        
        try {
            List<Consulta> historial_consultas = consultaDAO.obtenerHistorialConsultasMedicos(id_medico, id_paciente);
            List<ConsultaDTO> consultasDTO = new ArrayList<>();
            for (Consulta consulta : historial_consultas) {
                consultasDTO.add(Mapper.toDTO(consulta));
            }
            return consultasDTO;
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al obtener las consultas.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

}
