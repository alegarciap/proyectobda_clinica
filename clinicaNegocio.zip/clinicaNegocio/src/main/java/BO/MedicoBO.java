/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BO;

import DAO.IMedicoDAO;
import DAO.MedicoDAO;
import DTO.MedicoDTO;
import conexion.IConexion;
import entidades.Medico;
import excepciones.NegocioException;
import excepciones.PersistenciaException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import mapper.Mapper;

/**
 * La clase MedicoBO es responsable de manejar la lógica de negocio relacionada
 * con los médicos. Utiliza el patrón DAO para interactuar con la base de datos
 * a través de la interfaz IMedicoDAO.
 *
 * Esta clase proporciona métodos para activar o desactivar médicos, obtener una
 * lista de especialidades médicas, obtener médicos por especialidad y obtener
 * los datos de un médico específico.
 *
 * @author Alejandra García Preciado
 */
public class MedicoBO {

    /**
     * Logger utilizado para registrar errores y eventos.
     */
    private static final Logger logger = Logger.getLogger(MedicoBO.class.getName());

    /**
     * Instancia de la interfaz de acceso a datos de las citas.
     */
    private final IMedicoDAO medicoDAO;

    /**
     * Constructor de la clase MedicoBO.
     *
     * @param conexion la conexión utilizada para crear la instancia del DAO de
     * médico.
     */
    public MedicoBO(IConexion conexion) {
        this.medicoDAO = new MedicoDAO(conexion);
    }

    /**
     * Desactiva a un médico, dando de baja su cuenta en el sistema.
     *
     * @param medicoDTO el objeto de transferencia de datos que contiene la
     * información del médico a desactivar.
     * @throws NegocioException si el médico es nulo o si ocurre un error
     * relacionado con la lógica de negocio.
     */
    public void desactivarMedico(MedicoDTO medicoDTO) throws NegocioException { 
        if (medicoDTO == null) {
            throw new NegocioException("El médico a dar de baja no puede ser nulo.");
        }
        
        try {
            medicoDAO.desactivarMedico(Mapper.toEntity(medicoDTO)); 
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al dar de baja el médico.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

    /**
     * Activa a un médico, habilitando su cuenta en el sistema.
     *
     * @param medicoDTO el objeto de transferencia de datos que contiene la
     * información del médico a activar.
     * @throws NegocioException si el médico es nulo o si ocurre un error
     * relacionado con la lógica de negocio.
     */
    public void activarMedico(MedicoDTO medicoDTO) throws NegocioException {
        if (medicoDTO == null) {
            throw new NegocioException("El médico a activar no puede ser nulo.");
        }
        
        try {
            medicoDAO.activarMedico(Mapper.toEntity(medicoDTO));
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al activar médico.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

    /**
     * Obtiene una lista de especialidades médicas disponibles en el sistema.
     *
     * @return una lista de especialidades médicas.
     * @throws NegocioException si ocurre un error relacionado con la lógica de
     * negocio.
     */
    public List<String> obtenerEspecialidades() throws NegocioException { 
        try {
            return medicoDAO.obtenerEspecialidades();
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al obtener especialidades.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

    /**
     * Obtiene una lista de médicos que tienen una especialidad específica.
     *
     * @param especialidad la especialidad médica para filtrar los médicos.
     * @return una lista de nombres de médicos con la especialidad especificada.
     * @throws NegocioException si ocurre un error relacionado con la lógica de
     * negocio.
     */
    public List<MedicoDTO> obtenerMedicosPorEspecialidad(String especialidad) throws NegocioException { 
        try {
            List<Medico> medicos = medicoDAO.obtenerMedicosPorEspecialidad(especialidad);
            List<MedicoDTO> medicosDTO = new ArrayList<>();
            for (Medico medico : medicos) {
                medicosDTO.add(Mapper.toDTO(medico)); 
            }
            
            return medicosDTO;
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al obtener médicos.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

    /**
     * Obtiene los detalles de un médico específico a partir de su ID de
     * usuario.
     *
     * @param id_usuario el ID del usuario médico.
     * @return un objeto MedicoDTO con los detalles del médico, o null si no se
     * encuentra.
     * @throws NegocioException si el ID es inválido o si ocurre un error
     * relacionado con la lógica de negocio.
     */
    public MedicoDTO obtenerMedico(int id_usuario) throws NegocioException {
        if (id_usuario <= 0) {
            throw new NegocioException("ID inválido.");
        }

        try {
            Medico medico = medicoDAO.obtenerMedico(id_usuario);

            if (medico != null) {
                return Mapper.toDTO(medico);
            }
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al obtener médico.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
        return null;
    }

}
