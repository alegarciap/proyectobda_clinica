/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BO;

import DAO.IPacienteDAO;
import DAO.PacienteDAO;
import DTO.PacienteDTO;
import conexion.IConexion;
import entidades.Paciente;
import excepciones.NegocioException;
import excepciones.PersistenciaException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import mapper.Mapper;

/**
 * La clase PacienteBO es la capa de negocio encargada de manejar las
 * operaciones relacionadas con los pacientes. Esta clase interactúa con la capa
 * de acceso a datos (DAO) para registrar, actualizar, y obtener información
 * sobre pacientes. Además, realiza validaciones sobre los datos antes de
 * realizar cualquier operación.
 *
 * @author Alejandra García Preciado
 */
public class PacienteBO {

    /**
     * Logger utilizado para registrar errores y eventos.
     */
    private static final Logger logger = Logger.getLogger(PacienteBO.class.getName());

    /**
     * Instancia de la interfaz de acceso a datos de las citas.
     */
    private final IPacienteDAO pacienteDAO;

    /**
     * Constructor de la clase <code>PacienteBO</code>. Inicializa la capa de
     * acceso a datos de pacientes.
     *
     * @param conexion La conexión a la base de datos.
     */
    public PacienteBO(IConexion conexion) {
        this.pacienteDAO = new PacienteDAO(conexion);
    }

    /**
     * Registra un nuevo paciente en el sistema.
     *
     * @param pacienteDTO El objeto <code>PacienteDTO</code> que contiene los
     * datos del paciente.
     * @throws NegocioException Si ocurre un error durante la validación o
     * persistencia de los datos.
     */
    public void registrarPaciente(PacienteDTO pacienteDTO) throws NegocioException {
        // validar nombre
        if (pacienteDTO.getNombre() == null || pacienteDTO.getNombre().trim().isEmpty()) {
            throw new NegocioException("El nombre del paciente no debe estar vacío, es obligatorio.");
        }

        // validar apellido
        if (pacienteDTO.getApellido_paterno() == null || pacienteDTO.getApellido_paterno().trim().isEmpty()) {
            throw new NegocioException("El paciente debe registrar al menos un apellido.");
        }

        // validar direccion
        if (pacienteDTO.getDireccion() == null || pacienteDTO.getDireccion().trim().isEmpty()) {
            throw new NegocioException("La dirección del paciente debe ser registrada");
        }
        // validar telefono
        Pattern regexTelefono = Pattern.compile("^\\d{10}$");
        if (pacienteDTO.getTelefono() == null || !regexTelefono.matcher(pacienteDTO.getTelefono().trim()).matches()) {
            throw new NegocioException("Número de teléfono inválido. Debe contener 10 dígitos.");
        }

        // validar correo
        Pattern regexCorreo = Pattern.compile("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,6}$");
        if (pacienteDTO.getCorreo() == null || !regexCorreo.matcher(pacienteDTO.getCorreo().trim()).matches()) {
            throw new NegocioException("Correo electrónico inválido.");
        }

        // validar nombre usuario
        if (pacienteDTO.getUsuario().getNombre() == null || pacienteDTO.getUsuario().getNombre().trim().isEmpty()) {
            throw new NegocioException("El nombre de usuario no debe estar vacío.");
        }

        // validar contraseña
        if (pacienteDTO.getUsuario().getContrasenia() == null || pacienteDTO.getUsuario().getContrasenia().trim().isEmpty()
                || pacienteDTO.getUsuario().getContrasenia().length() < 8) {
            throw new NegocioException("La contraseña debe contener mínimo 8 caracteres.");
        }

        try {
            pacienteDAO.registrarPaciente(Mapper.toEntity(pacienteDTO));
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al registrar paciente.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

    /**
     * Actualiza la información de un paciente en el sistema.
     *
     * @param pacienteDTO El objeto <code>PacienteDTO</code> que contiene los
     * nuevos datos del paciente.
     * @throws NegocioException Si ocurre un error durante la validación o
     * persistencia de los datos.
     */
    public void actualizarPaciente(PacienteDTO pacienteDTO) throws NegocioException {
        // validar nombre
        if (pacienteDTO.getNombre() == null || pacienteDTO.getNombre().trim().isEmpty()) {
            throw new NegocioException("El nombre del paciente no debe estar vacío, es obligatorio.");
        }

        // validar apellido
        if (pacienteDTO.getApellido_paterno() == null || pacienteDTO.getApellido_paterno().trim().isEmpty()) {
            throw new NegocioException("El paciente debe registrar al menos un apellido.");
        }

        // validar direccion
        if (pacienteDTO.getDireccion() == null || pacienteDTO.getDireccion().trim().isEmpty()) {
            throw new NegocioException("La dirección del paciente debe ser registrada");
        }
        // validar telefono
        Pattern regexTelefono = Pattern.compile("^\\d{10}$");
        if (pacienteDTO.getTelefono() == null || !regexTelefono.matcher(pacienteDTO.getTelefono().trim()).matches()) {
            throw new NegocioException("Número de teléfono inválido. Debe contener 10 dígitos.");
        }

        // validar correo
        Pattern regexCorreo = Pattern.compile("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,6}$");
        if (pacienteDTO.getCorreo() == null || !regexCorreo.matcher(pacienteDTO.getCorreo().trim()).matches()) {
            throw new NegocioException("Correo electrónico inválido.");
        }

        try {
            pacienteDAO.actualizarPaciente(Mapper.toEntity(pacienteDTO));
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al actualizar paciente.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

    /**
     * Obtiene los datos de un paciente a partir de su ID.
     *
     * @param id_usuario El ID del paciente a consultar.
     * @return El objeto <code>PacienteDTO</code> con los datos del paciente.
     * @throws NegocioException Si ocurre un error al validar el ID o en la capa
     * de persistencia.
     */
    public PacienteDTO obtenerPaciente(int id_usuario) throws NegocioException {
        if (id_usuario <= 0) {
            throw new NegocioException("ID usuario inválido.");
        }

        try {
            Paciente paciente = pacienteDAO.obtenerPaciente(id_usuario);

            if (paciente != null) {
                return Mapper.toDTO(paciente);
            }
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al obtener paciente.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
        return null;
    }
    
    /**
     * Obtiene una lista de pacientes asociados a un médico específico y los
     * convierte a DTO.
     * <p>
     * Este método recupera los pacientes desde la capa de persistencia y los
     * transforma en objetos {@code PacienteDTO} para ser utilizados en la capa
     * de negocio.
     * </p>
     *
     * @param id_medico El identificador único del médico cuyos pacientes se
     * desean obtener.
     * @return Una lista de objetos {@code PacienteDTO} que representan a los
     * pacientes del médico.
     * @throws NegocioException Si ocurre un error al acceder a los datos de los
     * pacientes.
     */
    public List<PacienteDTO> obtenerPacientesPorMedico(int id_medico) throws NegocioException {
        try {
            List<Paciente> pacientes = pacienteDAO.obtenerPacientesPorMedico(id_medico);
            List<PacienteDTO> pacientesDTO = new ArrayList<>();
            for (Paciente paciente : pacientes) {
                pacientesDTO.add(Mapper.toDTO(paciente));
            }

            return pacientesDTO;
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al obtener pacientes.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

}
