/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BO;

import DAO.IUsuarioDAO;
import DAO.UsuarioDAO;
import DTO.UsuarioDTO;
import conexion.IConexion;
import excepciones.NegocioException;
import excepciones.PersistenciaException;
import java.util.logging.Level;
import java.util.logging.Logger;
import mapper.Mapper;

/**
 * La clase UsuarioBO es la capa de negocio encargada de manejar las operaciones
 * relacionadas con los usuarios. Esta clase interactúa con la capa de acceso a
 * datos (DAO) para autenticar usuarios, obtener información sobre el tipo de
 * usuario y su ID, y validar los datos antes de realizar cualquier operación.
 *
 * @author Alejandra García Preciado
 */
public class UsuarioBO {

    /**
     * Logger utilizado para registrar errores y eventos.
     */
    private static final Logger logger = Logger.getLogger(UsuarioBO.class.getName());

    /**
     * Instancia de la interfaz de acceso a datos de las citas.
     */
    private final IUsuarioDAO usuarioDAO;

    /**
     * Constructor de la clase UsuarioBO. Inicializa la capa de acceso a datos
     * de usuarios.
     *
     * @param conexion La conexión a la base de datos.
     */
    public UsuarioBO(IConexion conexion) {
        this.usuarioDAO = new UsuarioDAO(conexion);
    }

    /**
     * Inicia sesión de un usuario verificando sus credenciales.
     *
     * @param usuarioDTO El objeto <code>UsuarioDTO</code> que contiene los
     * datos del usuario a autenticar.
     * @return <code>true</code> si las credenciales son correctas, de lo
     * contrario <code>false</code>.
     * @throws NegocioException Si ocurre un error durante la validación o
     * persistencia de los datos.
     */
    public boolean iniciarSesion(UsuarioDTO usuarioDTO) throws NegocioException {
        if (usuarioDTO.getNombre() == null || usuarioDTO.getNombre().trim().isEmpty()) {
            throw new NegocioException("El nombe de usuario no puede estar vacío");
        }

        if (usuarioDTO.getContrasenia() == null || usuarioDTO.getContrasenia().trim().isEmpty() || usuarioDTO.getContrasenia().length() < 8) {
            throw new NegocioException("La contraseña debe tener mínimo 8 caracteres");
        }

        try {
            return usuarioDAO.iniciarSesion(Mapper.toEntity(usuarioDTO));
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al iniciar sesión.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

    /**
     * Obtiene el tipo de usuario a partir de su ID.
     *
     * @param id_usuario El ID del usuario para obtener su tipo.
     * @return El tipo de usuario como una cadena de texto.
     * @throws NegocioException Si ocurre un error en la validación o en la capa
     * de persistencia.
     */
    public String obtenerTipoUsuario(int id_usuario) throws NegocioException {
        try {
            return usuarioDAO.obtenerTipoUsuario(id_usuario);
        } catch (PersistenciaException ex) {
            logger.log(Level.SEVERE, "Error al iniciar sesión.", ex);
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

    /**
     * Obtiene el ID de un usuario a partir de su nombre.
     *
     * @param usuarioDTO El objeto <code>UsuarioDTO</code> que contiene el
     * nombre del usuario.
     * @return El ID del usuario.
     * @throws NegocioException Si ocurre un error al obtener el ID del usuario.
     */
    public int obtenerIdUsuario(UsuarioDTO usuarioDTO) throws NegocioException {
        try {
            return usuarioDAO.obtenerIdUsuario(usuarioDTO.getNombre());
        } catch (PersistenciaException ex) {
            throw new NegocioException(ex.getMessage(), ex);
        }
    }

}
