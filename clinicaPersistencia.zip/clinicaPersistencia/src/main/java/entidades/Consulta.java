/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

import java.sql.Timestamp;

/**
 * Representa una consulta médica realizada en el sistema, almacenando
 * información sobre la fecha y hora de la consulta, el diagnóstico, el
 * tratamiento prescrito, observaciones y la cita asociada.
 *
 * @author Alejandra García Preciado
 */
public class Consulta {
    
    /**
     * Identificador único de la consulta.
     */
    private int id_consulta;

    /**
     * Fecha y hora en la que se realizó la consulta.
     */
    private Timestamp fecha_hora;

    /**
     * Diagnóstico proporcionado durante la consulta.
     */
    private String diagnostico;

    /**
     * Tratamiento recomendado al paciente.
     */
    private String tratamiento;

    /**
     * Observaciones adicionales realizadas por el médico.
     */
    private String observaciones;

    /**
     * Cita asociada a la consulta.
     */
    private Cita cita;

    /**
     * Constructor por defecto de la clase Consulta.
     */
    public Consulta() {
    }

    /**
     * Constructor que inicializa todos los atributos de la consulta.
     * 
     * @param id_consulta Identificador único de la consulta.
     * @param fecha_hora Fecha y hora en la que se realizó la consulta.
     * @param diagnostico Diagnóstico proporcionado durante la consulta.
     * @param tratamiento Tratamiento recomendado al paciente.
     * @param observaciones Observaciones adicionales del médico.
     * @param cita Cita asociada a la consulta.
     */
    public Consulta(int id_consulta, Timestamp fecha_hora, String diagnostico, String tratamiento, String observaciones, Cita cita) {
        this.id_consulta = id_consulta;
        this.fecha_hora = fecha_hora;
        this.diagnostico = diagnostico;
        this.tratamiento = tratamiento;
        this.observaciones = observaciones;
        this.cita = cita;
    }

    /**
     * Constructor que inicializa una consulta sin su identificador.
     * 
     * @param fecha_hora Fecha y hora en la que se realizó la consulta.
     * @param diagnostico Diagnóstico proporcionado durante la consulta.
     * @param tratamiento Tratamiento recomendado al paciente.
     * @param observaciones Observaciones adicionales del médico.
     * @param cita Cita asociada a la consulta.
     */
    public Consulta(Timestamp fecha_hora, String diagnostico, String tratamiento, String observaciones, Cita cita) {
        this.fecha_hora = fecha_hora;
        this.diagnostico = diagnostico;
        this.tratamiento = tratamiento;
        this.observaciones = observaciones;
        this.cita = cita;
    }

    /**
     * @return El identificador único de la consulta.
     */
    public int getId_consulta() {
        return id_consulta;
    }

    /**
     * @param id_consulta El nuevo identificador único de la consulta.
     */
    public void setId_consulta(int id_consulta) {
        this.id_consulta = id_consulta;
    }

    /**
     * @return La fecha y hora de la consulta.
     */
    public Timestamp getFecha_hora() {
        return fecha_hora;
    }

    /**
     * @param fecha_hora La nueva fecha y hora de la consulta.
     */
    public void setFecha_hora(Timestamp fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    /**
     * @return El diagnóstico de la consulta.
     */
    public String getDiagnostico() {
        return diagnostico;
    }

    /**
     * @param diagnostico El nuevo diagnóstico de la consulta.
     */
    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    /**
     * @return El tratamiento recomendado.
     */
    public String getTratamiento() {
        return tratamiento;
    }

    /**
     * @param tratamiento El nuevo tratamiento recomendado.
     */
    public void setTratamiento(String tratamiento) {
        this.tratamiento = tratamiento;
    }

    /**
     * @return Las observaciones adicionales del médico.
     */
    public String getObservaciones() {
        return observaciones;
    }

    /**
     * @param observaciones Las nuevas observaciones de la consulta.
     */
    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    /**
     * @return La cita asociada a la consulta.
     */
    public Cita getCita() {
        return cita;
    }

    /**
     * @param cita La nueva cita asociada a la consulta.
     */
    public void setCita(Cita cita) {
        this.cita = cita;
    }

    /**
     * Devuelve una representación en cadena de la consulta.
     *
     * @return Una cadena con los valores de los atributos de la consulta.
     */
    @Override
    public String toString() {
        return "Consulta{" + "id_consulta=" + id_consulta + ", fecha_hora=" + fecha_hora
                + ", diagnostico=" + diagnostico + ", tratamiento=" + tratamiento
                + ", observaciones=" + observaciones + ", cita=" + cita + '}';
    }
    
}
