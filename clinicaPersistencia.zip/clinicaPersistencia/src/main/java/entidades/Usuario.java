/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 * Representa a un usuario del sistema con un identificador, nombre y
 * contraseña. Proporciona métodos para acceder y modificar sus atributos.
 *
 * <p>
 * Incluye constructores para crear usuarios con o sin identificador.</p>
 *
 * @author Alejandra García Preciado
 */
public class Usuario {
    
    /**
     * Identificador único del usuario.
     */
    private int id_usuario;

    /**
     * Nombre del usuario.
     */
    private String nombre;

    /**
     * Contraseña del usuario.
     */
    private String contrasenia;

    /**
     * Constructor por defecto. Crea un usuario sin inicializar sus atributos.
     */
    public Usuario() {
    }

    /**
     * Constructor que inicializa todos los atributos del usuario.
     *
     * @param id_usuario Identificador único del usuario.
     * @param nombre Nombre del usuario.
     * @param contrasenia Contraseña del usuario.
     */
    public Usuario(int id_usuario, String nombre, String contrasenia) {
        this.id_usuario = id_usuario;
        this.nombre = nombre;
        this.contrasenia = contrasenia;
    }

    /**
     * Constructor que inicializa el usuario sin identificador.
     * 
     * @param nombre Nombre del usuario.
     * @param contrasenia Contraseña del usuario.
     */
    public Usuario(String nombre, String contrasenia) {
        this.nombre = nombre;
        this.contrasenia = contrasenia;
    }

    /**
     * Obtiene el identificador del usuario.
     * 
     * @return El identificador del usuario.
     */
    public int getId_usuario() {
        return id_usuario;
    }

    /**
     * Establece el identificador del usuario.
     *
     * @param id_usuario Nuevo identificador del usuario.
     */
    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    /**
     * Obtiene el nombre del usuario.
     *
     * @return El nombre del usuario.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del usuario.
     *
     * @param nombre Nuevo nombre del usuario.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la contraseña del usuario.
     *
     * @return La contraseña del usuario.
     */
    public String getContrasenia() {
        return contrasenia;
    }

    /**
     * Establece la contraseña del usuario.
     *
     * @param contrasenia Nueva contraseña del usuario.
     */
    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    /**
     * Devuelve una representación en cadena del usuario.
     *
     * @return Cadena con la información del usuario.
     */
    @Override
    public String toString() {
        return "Usuario{" + "id_usuario=" + id_usuario + ", nombre=" + nombre + ", contrasenia=" + contrasenia + '}';
    }
    
}
