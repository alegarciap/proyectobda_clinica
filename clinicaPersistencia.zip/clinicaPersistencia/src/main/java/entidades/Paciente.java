/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

import java.util.Date;

/**
 * Representa a un paciente dentro del sistema. Contiene información personal y
 * de contacto del paciente, así como su asociación con un usuario en el
 * sistema.
 *
 * @author Alejandra García Peciado
 */
public class Paciente {

    /**
     * Identificador único del paciente.
     */
    private int id_paciente;

    /**
     * Nombre del paciente.
     */
    private String nombre;

    /**
     * Apellido paterno del paciente.
     */
    private String apellido_paterno;

    /**
     * Apellido materno del paciente.
     */
    private String apellido_materno;

    /**
     * Dirección del paciente.
     */
    private String direccion;

    /**
     * Fecha de nacimiento del paciente.
     */
    private Date fecha_nacimiento;

    /**
     * Número de teléfono del paciente.
     */
    private String telefono;

    /**
     * Correo electrónico del paciente.
     */
    private String correo;

    /**
     * Usuario asociado al paciente en el sistema.
     */
    private Usuario usuario;

    /**
     * Constructor por defecto.
     */
    public Paciente() {
    }

    /**
     * Constructor que inicializa todos los atributos del paciente.
     *
     * @param id_paciente Identificador único del paciente.
     * @param nombre Nombre del paciente.
     * @param apellido_paterno Apellido paterno del paciente.
     * @param apellido_materno Apellido materno del paciente.
     * @param direccion Dirección de residencia del paciente.
     * @param fecha_nacimiento Fecha de nacimiento del paciente.
     * @param telefono Número de teléfono del paciente.
     * @param correo Correo electrónico del paciente.
     * @param usuario Usuario asociado al paciente.
     */
    public Paciente(int id_paciente, String nombre, String apellido_paterno, String apellido_materno, String direccion, Date fecha_nacimiento, String telefono, String correo, Usuario usuario) {
        this.id_paciente = id_paciente;
        this.nombre = nombre;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.direccion = direccion;
        this.fecha_nacimiento = fecha_nacimiento;
        this.telefono = telefono;
        this.correo = correo;
        this.usuario = usuario;
    }

    /**
     * Constructor sin ID, utilizado para la creación de nuevos pacientes.
     *
     * @param nombre Nombre del paciente.
     * @param apellido_paterno Apellido paterno del paciente.
     * @param apellido_materno Apellido materno del paciente.
     * @param direccion Dirección de residencia del paciente.
     * @param fecha_nacimiento Fecha de nacimiento del paciente.
     * @param telefono Número de teléfono del paciente.
     * @param correo Correo electrónico del paciente.
     * @param usuario Usuario asociado al paciente.
     */
    public Paciente(String nombre, String apellido_paterno, String apellido_materno, String direccion, Date fecha_nacimiento, String telefono, String correo, Usuario usuario) {
        this.nombre = nombre;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.direccion = direccion;
        this.fecha_nacimiento = fecha_nacimiento;
        this.telefono = telefono;
        this.correo = correo;
        this.usuario = usuario;
    }

    /**
     * @return Identificador único del paciente.
     */
    public int getId_paciente() {
        return id_paciente;
    }

    /**
     * @param id_paciente Nuevo identificador del paciente.
     */
    public void setId_paciente(int id_paciente) {
        this.id_paciente = id_paciente;
    }

    /**
     * @return Nombre del paciente.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre Nuevo nombre del paciente.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return Apellido paterno del paciente.
     */
    public String getApellido_paterno() {
        return apellido_paterno;
    }

    /**
     * @param apellido_paterno Nuevo apellido paterno del paciente.
     */
    public void setApellido_paterno(String apellido_paterno) {
        this.apellido_paterno = apellido_paterno;
    }

    /**
     * @return Apellido materno del paciente.
     */
    public String getApellido_materno() {
        return apellido_materno;
    }

    /**
     * @param apellido_materno Nuevo apellido materno del paciente.
     */
    public void setApellido_materno(String apellido_materno) {
        this.apellido_materno = apellido_materno;
    }

    /**
     * @return Dirección del paciente.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * @param direccion Nueva dirección del paciente.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * @return Fecha de nacimiento del paciente.
     */
    public Date getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    /**
     * @param fecha_nacimiento Nueva fecha de nacimiento del paciente.
     */
    public void setFecha_nacimiento(Date fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    /**
     * @return Número de teléfono del paciente.
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param telefono Nuevo número de teléfono del paciente.
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * @return Correo electrónico del paciente.
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @param correo Nuevo correo electrónico del paciente.
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * @return Usuario asociado al paciente.
     */
    public Usuario getUsuario() {
        return usuario;
    }

    /**
     * @param usuario Nuevo usuario asociado al paciente.
     */
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    /**
     * Devuelve una representación en cadena del paciente.
     *
     * @return Cadena con los atributos del paciente.
     */
    @Override
    public String toString() {
        return "Paciente{" + "id_paciente=" + id_paciente + ", nombre=" + nombre + ", apellido_paterno=" + apellido_paterno + ", apellido_materno=" + apellido_materno + ", direccion=" + direccion + ", fecha_nacimiento=" + fecha_nacimiento + ", telefono=" + telefono + ", correo=" + correo + '}';
    }

}
