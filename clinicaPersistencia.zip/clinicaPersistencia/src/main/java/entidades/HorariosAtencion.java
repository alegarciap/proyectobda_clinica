/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

import java.time.LocalTime;

/**
 * Representa el horario de atención de un médico, incluyendo el día de la
 * semana, la hora de entrada, la hora de salida y el médico correspondiente.
 *
 * @author Alejandra García Preciado
 */
public class HorariosAtencion {
    
    /**
     * Identificador único del horario de atención.
     */
    private int id_horario;

    /**
     * Día de la semana en el que aplica el horario.
     */
    private String dia;

    /**
     * Hora de inicio del horario de atención.
     */
    private LocalTime hora_entrada;

    /**
     * Hora de finalización del horario de atención.
     */
    private LocalTime hora_salida;

    /**
     * Médico al que pertenece el horario de atención.
     */
    private Medico medico;

    /**
     * Constructor por defecto de la clase HorariosAtencion.
     */
    public HorariosAtencion() {
    }

    /**
     * Constructor que inicializa todos los atributos del horario de atención.
     * 
     * @param id_horario Identificador único del horario.
     * @param dia Día de la semana en el que aplica el horario.
     * @param hora_entrada Hora de inicio del horario de atención.
     * @param hora_salida Hora de finalización del horario de atención.
     * @param medico Médico al que pertenece el horario.
     */
    public HorariosAtencion(int id_horario, String dia, LocalTime hora_entrada, LocalTime hora_salida, Medico medico) {
        this.id_horario = id_horario;
        this.dia = dia;
        this.hora_entrada = hora_entrada;
        this.hora_salida = hora_salida;
        this.medico = medico;
    }

    /**
     * Constructor que inicializa un horario de atención sin su identificador.
     *
     * @param dia Día de la semana en el que aplica el horario.
     * @param hora_entrada Hora de inicio del horario de atención.
     * @param hora_salida Hora de finalización del horario de atención.
     * @param medico Médico al que pertenece el horario.
     */
    public HorariosAtencion(String dia, LocalTime hora_entrada, LocalTime hora_salida, Medico medico) {
        this.dia = dia;
        this.hora_entrada = hora_entrada;
        this.hora_salida = hora_salida;
        this.medico = medico;
    }

    /**
     * @return El identificador único del horario de atención.
     */
    public int getId_horario() {
        return id_horario;
    }

    /**
     * @param id_horario El nuevo identificador único del horario de atención.
     */
    public void setId_horario(int id_horario) {
        this.id_horario = id_horario;
    }

    /**
     * @return El día de la semana en el que aplica el horario.
     */
    public String getDia() {
        return dia;
    }

    /**
     * @param dia El nuevo día de la semana para el horario.
     */
    public void setDia(String dia) {
        this.dia = dia;
    }

    /**
     * @return La hora de inicio del horario de atención.
     */
    public LocalTime getHora_entrada() {
        return hora_entrada;
    }

    /**
     * @param hora_entrada La nueva hora de inicio del horario de atención.
     */
    public void setHora_entrada(LocalTime hora_entrada) {
        this.hora_entrada = hora_entrada;
    }

    /**
     * @return La hora de finalización del horario de atención.
     */
    public LocalTime getHora_salida() {
        return hora_salida;
    }

    /**
     * @param hora_salida La nueva hora de finalización del horario de atención.
     */
    public void setHora_salida(LocalTime hora_salida) {
        this.hora_salida = hora_salida;
    }

    /**
     * @return El médico al que pertenece el horario.
     */
    public Medico getMedico() {
        return medico;
    }

    /**
     * @param medico El nuevo médico asociado al horario de atención.
     */
    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    /**
     * Devuelve una representación en cadena del horario de atención.
     *
     * @return Una cadena con los valores de los atributos del horario.
     */
    @Override
    public String toString() {
        return "HorariosAtencion{" + "id_horario=" + id_horario + ", dia=" + dia
                + ", hora_entrada=" + hora_entrada + ", hora_salida=" + hora_salida
                + ", medico=" + medico + '}';
    }
    
}
