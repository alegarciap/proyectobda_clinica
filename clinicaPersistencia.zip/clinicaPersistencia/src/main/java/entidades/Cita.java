/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

import java.sql.Timestamp;

/**
 * Representa una cita médica en el sistema, almacenando información sobre la
 * fecha y hora, el estado de la cita, el folio único, el médico asignado y el
 * paciente correspondiente.
 *
 * @author Alejandra García Preciado
 */
public class Cita {

    /**
     * Identificador único de la cita.
     */
    private int id_cita;

    /**
     * Fecha y hora en la que se programó la cita.
     */
    private Timestamp fecha_hora;

    /**
     * Estado actual de la cita.
     */
    private String estado;

    /**
     * Folio único asociado a la cita (solo cuando son de emergencia).
     */
    private String folio;

    /**
     * Médico asignado a la cita.
     */
    private Medico medico;

    /**
     * Paciente que tiene la cita.
     */
    private Paciente paciente;

    /**
     * Constructor por defecto de la clase Cita.
     */
    public Cita() {
    }

    /**
     * Constructor que inicializa todos los atributos de la cita.
     *
     * @param id_cita Identificador único de la cita.
     * @param fecha_hora Fecha y hora en la que se programó la cita.
     * @param estado Estado actual de la cita.
     * @param folio Folio único asociado a la cita.
     * @param medico Médico asignado a la cita.
     * @param paciente Paciente que tiene la cita.
     */
    public Cita(int id_cita, Timestamp fecha_hora, String estado, String folio, Medico medico, Paciente paciente) {
        this.id_cita = id_cita;
        this.fecha_hora = fecha_hora;
        this.estado = estado;
        this.folio = folio;
        this.medico = medico;
        this.paciente = paciente;
    }

    /**
     * Constructor que inicializa la cita sin un identificador explícito.
     *
     * @param fecha_hora Fecha y hora en la que se programó la cita.
     * @param estado Estado actual de la cita.
     * @param folio Folio único asociado a la cita.
     * @param medico Médico asignado a la cita.
     * @param paciente Paciente que tiene la cita.
     */
    public Cita(Timestamp fecha_hora, String estado, String folio, Medico medico, Paciente paciente) {
        this.fecha_hora = fecha_hora;
        this.estado = estado;
        this.folio = folio;
        this.medico = medico;
        this.paciente = paciente;
    }

    /**
     * @return El identificador único de la cita.
     */
    public int getId_cita() {
        return id_cita;
    }

    /**
     * @param id_cita El nuevo identificador único de la cita.
     */
    public void setId_cita(int id_cita) {
        this.id_cita = id_cita;
    }

    /**
     * @return La fecha y hora de la cita.
     */
    public Timestamp getFecha_hora() {
        return fecha_hora;
    }

    /**
     * @param fecha_hora La nueva fecha y hora de la cita.
     */
    public void setFecha_hora(Timestamp fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    /**
     * @return El estado actual de la cita.
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado El nuevo estado de la cita.
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * @return El folio único de la cita.
     */
    public String getFolio() {
        return folio;
    }

    /**
     * @param folio El nuevo folio único de la cita.
     */
    public void setFolio(String folio) {
        this.folio = folio;
    }

    /**
     * @return El médico asignado a la cita.
     */
    public Medico getMedico() {
        return medico;
    }

    /**
     * @param medico El nuevo médico asignado a la cita.
     */
    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    /**
     * @return El paciente que tiene la cita.
     */
    public Paciente getPaciente() {
        return paciente;
    }

    /**
     * @param paciente El nuevo paciente de la cita.
     */
    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    /**
     * Devuelve una representación en cadena de la cita.
     *
     * @return Una cadena con los valores de los atributos de la cita.
     */
    @Override
    public String toString() {
        return "Cita{" + "id_cita=" + id_cita + ", fecha_hora=" + fecha_hora
                + ", estado=" + estado + ", folio=" + folio
                + ", medico=" + medico + ", paciente=" + paciente + '}';
    }

}
