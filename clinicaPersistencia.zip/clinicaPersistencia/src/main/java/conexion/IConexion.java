/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package conexion;

import excepciones.PersistenciaException;
import java.sql.Connection;

/**
 * Interfaz que define la creación de una conexión a una base
 * de datos. Las clases que implementen esta interfaz deben proporcionar la
 * implementación para establecer una conexión con una base de datos, lanzando
 * una excepción personalizada {@link PersistenciaException} en caso de error.
 *
 * @author Alejandra García Preciado
 */
public interface IConexion {
    
    /**
     * Crea una conexión a la base de datos.
     *
     * @return Una instancia de {@link Connection} representando la conexión
     * establecida.
     * @throws PersistenciaException Si ocurre un error al intentar crear la
     * conexión.
     */
    public Connection crearConexion() throws PersistenciaException;
    
}
