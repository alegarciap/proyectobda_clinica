/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import excepciones.PersistenciaException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Implementación de la interfaz {@link IConexion} que maneja la creación de una
 * conexión a una base de datos MySQL. Esta clase utiliza {@link DriverManager}
 * para obtener una conexión y lanzar una {@link PersistenciaException} en caso
 * de fallos durante el proceso.
 *
 * <p>
 * Contiene los detalles de la URL, usuario y contraseña necesarios para
 * conectar a la base de datos.</p>
 *
 * @author alega
 */
public class Conexion implements IConexion {

    // URL de la base de datos, usuario y contraseña
    final String URL = "jdbc:mysql://127.0.0.1:3306/clinica";
    final String USER = "alegarciap";
    final String PASS = "sasden-juxhu8-kydsaF";

    /**
     * Implementación del método {@link IConexion#crearConexion()} que establece
     * la conexión con la base de datos MySQL usando los detalles de conexión
     * configurados.
     *
     * @return Un objeto {@link Connection} representando la conexión con la
     * base de datos.
     * @throws PersistenciaException Si ocurre un error al establecer la
     * conexión con la base de datos.
     */
    @Override
    public Connection crearConexion() throws PersistenciaException {
        try {
            Connection conexion = DriverManager.getConnection(URL, USER, PASS);
            return conexion;
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException("Error al generar la conexión");
        }
    }

}
