/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAO;

import entidades.Consulta;
import excepciones.PersistenciaException;
import java.sql.Timestamp;
import java.util.List;

/**
 * Interfaz que define los métodos necesarios para realizar operaciones sobre
 * consultas médicas. Esta interfaz es implementada por clases que gestionan el
 * acceso a la base de datos para realizar y obtener historial de consultas
 * médicas.
 * 
 * @author Alejandra García Preciado
 */
public interface IConsultaDAO {
    
    /**
     * Realiza una consulta médica y la guarda en la base de datos.
     *
     * @param consulta La consulta médica que se va a realizar.
     * @throws PersistenciaException Si ocurre un error al guardar la consulta
     * en la base de datos.
     */
    public void realizarConsulta(Consulta consulta) throws PersistenciaException;
    
    /**
     * Obtiene el historial de consultas de un paciente filtrado por
     * especialidad y rango de fechas.
     *
     * @param idPaciente El ID del paciente cuyo historial se desea obtener.
     * @param especialidad La especialidad médica a filtrar (puede ser nula para
     * no filtrar).
     * @param fechaInicio La fecha de inicio del rango a filtrar (puede ser nula
     * para no filtrar).
     * @param fechaFin La fecha de fin del rango a filtrar (puede ser nula para
     * no filtrar).
     * @return Una lista de objetos {@link Consulta} que representan el
     * historial de consultas del paciente.
     * @throws PersistenciaException Si ocurre un error al obtener las consultas
     * de la base de datos.
     */
    public List<Consulta> obtenerHistorialConsultas(int idPaciente, String especialidad, Timestamp fechaInicio, Timestamp fechaFin) throws PersistenciaException;
    
    /**
     * Obtiene el historial de consultas de un paciente con un médico
     * específico.
     *
     * @param id_medico El ID del médico que atendió las consultas.
     * @param id_paciente El ID del paciente cuyo historial se desea obtener.
     * @return Una lista de objetos {@link Consulta} que representan el
     * historial de consultas del paciente con el médico.
     * @throws PersistenciaException Si ocurre un error al obtener las consultas
     * de la base de datos.
     */
    public List<Consulta> obtenerHistorialConsultasMedicos(int id_medico, int id_paciente) throws PersistenciaException;
    
        
}
