/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAO;

import entidades.Medico;
import excepciones.PersistenciaException;
import java.util.List;

/**
 * Interfaz que define las operaciones relacionadas con la persistencia de los
 * médicos en la base de datos. Contiene métodos para obtener información de los
 * médicos, activarlos, desactivarlos y obtener especialidades.
 *
 * @author Alejandra García Preciado
 */
public interface IMedicoDAO {

    /**
     * Obtiene la información de un médico a partir de su ID de usuario.
     *
     * @param id_usuario El ID de usuario del médico.
     * @return Un objeto de tipo {@link Medico} con la información del médico.
     * @throws PersistenciaException Si ocurre un error al obtener el médico.
     */
    public Medico obtenerMedico(int id_usuario) throws PersistenciaException;

    /**
     * Cambia el estado del médico a 'inactivo' en la base de datos.
     *
     * @param medico El objeto {@link Medico} que se desea desactivar.
     * @throws PersistenciaException Si ocurre un error al desactivar el médico.
     */
    public void desactivarMedico(Medico medico) throws PersistenciaException;

    /**
     * Cambia el estado del médico a 'activo' en la base de datos.
     *
     * @param medico El objeto {@link Medico} que se desea activar.
     * @throws PersistenciaException Si ocurre un error al activar el médico.
     */
    public void activarMedico(Medico medico) throws PersistenciaException;

    /**
     * Obtiene todas las especialidades disponibles de los médicos.
     *
     * @return Una lista de cadenas con las especialidades de los médicos.
     * @throws PersistenciaException Si ocurre un error al obtener las
     * especialidades.
     */
    public List<String> obtenerEspecialidades() throws PersistenciaException;

    /**
     * Obtiene los médicos que pertenecen a una especialidad específica.
     *
     * @param especialidad La especialidad de los médicos que se desean obtener.
     * @return Una lista de nombres de médicos que pertenecen a la especialidad
     * solicitada.
     * @throws PersistenciaException Si ocurre un error al obtener los médicos
     * por especialidad.
     */
    public List<Medico> obtenerMedicosPorEspecialidad(String especialidad) throws PersistenciaException;

}
