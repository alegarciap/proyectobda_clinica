/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import conexion.IConexion;
import entidades.Cita;
import entidades.Medico;
import entidades.Paciente;
import excepciones.PersistenciaException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Implementación de la interfaz {@link ICitaDAO} para gestionar las citas de
 * los pacientes en un sistema de base de datos. Esta clase realiza operaciones
 * como agendar, cancelar y obtener citas, utilizando procedimientos almacenados
 * en la base de datos.
 *
 * <p>
 * Utiliza la clase {@link IConexion} para crear una conexión a la base de datos
 * y ejecutar comandos SQL relacionados con las citas.</p>
 *
 * @author Alejandra García Preciado
 */
public class CitaDAO implements ICitaDAO {

    IConexion conexion;

    /**
     * Constructor que recibe una instancia de {@link IConexion} para establecer
     * la conexión a la base de datos.
     *
     * @param conexion Objeto que implementa la interfaz {@link IConexion} para
     * crear la conexión.
     */
    public CitaDAO(IConexion conexion) {
        this.conexion = conexion;
    }

    /**
     * Agenda una cita para un paciente con un médico.
     *
     * @param cita Objeto {@link Cita} que contiene la información de la cita a
     * agendar.
     * @throws PersistenciaException Si ocurre un error al intentar agendar la
     * cita.
     */
    @Override
    public void agendarCita(Cita cita) throws PersistenciaException {
        String comandoSQL = "call agendar_cita(?,?,?);";

        try (Connection con = this.conexion.crearConexion(); CallableStatement cb = con.prepareCall(comandoSQL)) {
            cb.setTimestamp(1, cita.getFecha_hora());
            cb.setInt(2, cita.getPaciente().getId_paciente());
            cb.setInt(3, cita.getMedico().getId_medico());

            cb.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CitaDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException(ex.getMessage(), ex);
        }
    }

    /**
     * Agenda una cita de emergencia para un paciente.
     *
     * @param cita Objeto {@link Cita} que contiene la información de la cita de
     * emergencia.
     * @return cita Objeto {@link Cita} de emergencia generada
     * @throws PersistenciaException Si ocurre un error al intentar agendar la
     * cita de emergencia.
     */
    @Override
    public Cita agendarCitaEmergencia(Cita cita) throws PersistenciaException {
        String comandoSQL = "call agendar_cita_emergencia(?,?,?);";

        try (Connection con = this.conexion.crearConexion(); 
                CallableStatement cb = con.prepareCall(comandoSQL)) {
            cb.setInt(1, cita.getPaciente().getId_paciente());
            cb.registerOutParameter(2, Types.CHAR);  
            cb.registerOutParameter(3, Types.VARCHAR);

            cb.executeUpdate();
            
            String folio = cb.getString(2);
            String nombreMedico = cb.getString(3);
            
            cita.setFolio(folio);
            
            Medico medico = new Medico();
            medico.setNombre(nombreMedico);
            cita.setMedico(medico);

            return cita;
        } catch (SQLException ex) {
            Logger.getLogger(CitaDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException(ex.getMessage(), ex);
        }
    }

    /**
     * Cancela una cita previamente agendada.
     *
     * @param cita Objeto {@link Cita} que contiene la información de la cita a
     * cancelar.
     * @throws PersistenciaException Si ocurre un error al intentar cancelar la
     * cita.
     */
    @Override
    public void cancelarCita(Cita cita) throws PersistenciaException {
        String comandoSQL = "call cancelar_cita(?,?);";

        try (Connection con = this.conexion.crearConexion(); 
                CallableStatement cb = con.prepareCall(comandoSQL)) {
            cb.setInt(1, cita.getId_cita());
            cb.setInt(2, cita.getPaciente().getId_paciente());
            
            cb.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CitaDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException(ex.getMessage(), ex);
        }
    }

    /**
     * Obtiene las citas programadas para un médico específico.
     *
     * @param id_medico ID del médico cuyas citas se desean obtener.
     * @return Lista de objetos {@link Cita} con las citas programadas para el
     * médico.
     * @throws PersistenciaException Si ocurre un error al obtener las citas del
     * médico.
     */
    @Override
    public List<Cita> obtenerCitasMedico(int id_medico) throws PersistenciaException {
        List<Cita> citas = new ArrayList<>();
        String consultaSQL = "select c.id_cita, c.fecha_hora, c.folio, p.id_paciente, p.nombre, p.apellido_paterno, p.apellido_materno "
                + "from citas c "
                + "inner join pacientes p on c.id_paciente = p.id_paciente "
                + "where c.id_medico = ? and c.estado = 'programada' "
                + "order by c.fecha_hora asc;";

        try (Connection con = conexion.crearConexion(); PreparedStatement ps = con.prepareStatement(consultaSQL)) {
            ps.setInt(1, id_medico);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Paciente paciente = new Paciente();
                paciente.setId_paciente(rs.getInt("id_paciente"));
                paciente.setNombre(rs.getString("nombre"));
                paciente.setApellido_paterno(rs.getString("apellido_paterno"));
                paciente.setApellido_materno(rs.getString("apellido_materno"));

                Cita cita = new Cita();
                cita.setId_cita(rs.getInt("id_cita"));
                cita.setFecha_hora(rs.getTimestamp("fecha_hora"));
                cita.setFolio(rs.getString("folio"));
                cita.setPaciente(paciente);

                citas.add(cita);
            }

        } catch (SQLException ex) {
            Logger.getLogger(CitaDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException("Error al obtener las citas del médico.", ex);
        }
        return citas;
    }

    /**
     * Obtiene las citas programadas para un paciente específico.
     *
     * @param id_paciente ID del paciente cuyas citas se desean obtener.
     * @return Lista de objetos {@link Cita} con las citas programadas para el
     * paciente.
     * @throws PersistenciaException Si ocurre un error al obtener las citas del
     * paciente.
     */
    @Override
    public List<Cita> obtenerCitasPaciente(int id_paciente) throws PersistenciaException {
        List<Cita> citas = new ArrayList<>();
        String consultaSQL = "select c.id_cita, c.fecha_hora, c.estado, m.nombre, m.apellido_paterno, m.especialidad "
                + "from citas c "
                + "inner join medicos m on c.id_medico = m.id_medico "
                + "where c.id_paciente = ? and c.estado = 'programada' "
                + "order by c.fecha_hora asc;";

        try (Connection con = conexion.crearConexion(); PreparedStatement ps = con.prepareStatement(consultaSQL)) {
            ps.setInt(1, id_paciente);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Cita cita = new Cita();
                cita.setId_cita(rs.getInt("id_cita"));
                cita.setFecha_hora(rs.getTimestamp("fecha_hora"));
                cita.setEstado(rs.getString("estado"));

                Medico medico = new Medico();
                medico.setNombre(rs.getString("nombre"));
                medico.setApellido_paterno(rs.getString("apellido_paterno"));
                medico.setEspecialidad(rs.getString("especialidad"));

                cita.setMedico(medico);
                citas.add(cita);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CitaDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException("Error al obtener las citas del paciente.", ex);
        }
        return citas;
    }

}
