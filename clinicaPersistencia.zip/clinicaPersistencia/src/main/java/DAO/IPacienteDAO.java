/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAO;

import entidades.Paciente;
import excepciones.PersistenciaException;
import java.util.List;

/**
 * Interface que define los métodos para la gestión de pacientes en la base de
 * datos. Proporciona operaciones para registrar, obtener y actualizar la
 * información de un paciente.
 *
 * @author Alejandra García Preciado
 */
public interface IPacienteDAO {

    /**
     * Registra un nuevo paciente en la base de datos. Se asegura de registrar
     * tanto al usuario como al paciente en las tablas correspondientes.
     *
     * @param paciente Objeto de tipo {@link Paciente} que contiene la
     * información del paciente a registrar.
     * @throws PersistenciaException Si ocurre un error durante el proceso de
     * registro en la base de datos.
     */
    public void registrarPaciente(Paciente paciente) throws PersistenciaException;

    /**
     * Obtiene los detalles de un paciente a partir de su ID de usuario.
     *
     * @param id_usuario ID del usuario asociado al paciente.
     * @return Un objeto de tipo {@link Paciente} con la información del
     * paciente.
     * @throws PersistenciaException Si ocurre un error relacionado con la
     * persistencia de los datos.
     */
    public Paciente obtenerPaciente(int id_usuario) throws PersistenciaException;

    /**
     * Actualiza la información de un paciente en la base de datos.
     *
     * @param paciente Objeto de tipo {@link Paciente} que contiene la
     * información actualizada del paciente.
     * @throws PersistenciaException Si ocurre un error durante el proceso de
     * actualización en la base de datos.
     */
    public void actualizarPaciente(Paciente paciente) throws PersistenciaException;
    
    public List<Paciente> obtenerPacientesPorMedico(int id_medico) throws PersistenciaException;

}
