/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAO;

import entidades.Cita;
import excepciones.PersistenciaException;
import java.util.List;

/**
 * Interfaz que define las operaciones relacionadas con la gestión de citas en
 * el sistema. Incluye métodos para agendar, cancelar y obtener citas tanto para
 * pacientes como para médicos. Las clases que implementen esta interfaz deberán
 * proporcionar la implementación de estos métodos y manejar las excepciones
 * personalizadas {@link PersistenciaException}.
 *
 * @author Alejandra García Preciado
 */
public interface ICitaDAO {

    /**
     * Agendar una cita para un paciente con un médico.
     *
     * @param cita Objeto {@link Cita} que contiene los detalles de la cita a
     * agendar.
     * @throws PersistenciaException Si ocurre un error al intentar agendar la
     * cita.
     */
    public void agendarCita(Cita cita) throws PersistenciaException;

    /**
     * Agendar una cita de emergencia para un paciente.
     *
     * @param cita Objeto {@link Cita} que contiene los detalles de la cita de
     * emergencia.
     * @throws PersistenciaException Si ocurre un error al intentar agendar la
     * cita de emergencia.
     */
    public Cita agendarCitaEmergencia(Cita cita) throws PersistenciaException;

    /**
     * Cancelar una cita para un paciente.
     *
     * @param cita Objeto {@link Cita} que contiene los detalles de la cita a
     * cancelar.
     * @throws PersistenciaException Si ocurre un error al intentar cancelar la
     * cita.
     */
    public void cancelarCita(Cita cita) throws PersistenciaException;

    /**
     * Obtener las citas programadas para un médico específico.
     *
     * @param id_medico ID del médico cuya lista de citas se desea obtener.
     * @return Lista de objetos {@link Cita} con las citas programadas para el
     * médico.
     * @throws PersistenciaException Si ocurre un error al obtener las citas del
     * médico.
     */
    public List<Cita> obtenerCitasMedico(int id_medico) throws PersistenciaException;

    /**
     * Obtener las citas programadas para un paciente específico.
     *
     * @param id_paciente ID del paciente cuya lista de citas se desea obtener.
     * @return Lista de objetos {@link Cita} con las citas programadas para el
     * paciente.
     * @throws PersistenciaException Si ocurre un error al obtener las citas del
     * paciente.
     */
    public List<Cita> obtenerCitasPaciente(int id_paciente) throws PersistenciaException;

}
