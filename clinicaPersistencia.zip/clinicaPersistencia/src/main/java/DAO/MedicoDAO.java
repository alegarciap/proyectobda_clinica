/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import conexion.IConexion;
import entidades.Medico;
import entidades.Usuario;
import excepciones.PersistenciaException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Implementación de la interfaz {@link IMedicoDAO} que proporciona métodos para
 * acceder y modificar la información de los médicos en la base de datos.
 * Realiza operaciones como obtener la información de un médico, activar,
 * desactivar y obtener especialidades.
 *
 * @author Alejandra García Preciado
 */
public class MedicoDAO implements IMedicoDAO {
    
    IConexion conexion;

    /**
     * Constructor que recibe una instancia de conexión.
     *
     * @param conexion Instancia de {@link IConexion} para establecer la
     * conexión a la base de datos.
     */
    public MedicoDAO(IConexion conexion) {
        this.conexion = conexion;
    }
    
    /**
     * Obtiene la información de un médico a partir de su ID de usuario.
     *
     * @param id_usuario El ID de usuario del médico.
     * @return Un objeto de tipo {@link Medico} con la información del médico.
     * @throws PersistenciaException Si ocurre un error al obtener el médico.
     */
    @Override
    public Medico obtenerMedico(int id_usuario) throws PersistenciaException {
        String comandoSQL = "select m.id_medico, m.nombre as nombre_medico, m.apellido_paterno, m.apellido_materno, m.cedula,"
                + "m.especialidad, m.estado, u.id_usuario, u.nombre as nombre_usuario, u.contrasenia from medicos m "
                + "join usuarios u on m.id_medico = u.id_usuario "
                + "where m.id_medico = ?"; 
        
        try (Connection con = conexion.crearConexion(); 
                PreparedStatement st = con.prepareStatement(comandoSQL)) {
            st.setInt(1, id_usuario);
            
            try (ResultSet rs = st.executeQuery()) {
                if (rs.next()) {
                    Medico medico = new Medico();
                    medico.setId_medico(rs.getInt("id_medico"));
                    medico.setNombre(rs.getString("nombre_medico"));
                    medico.setApellido_paterno(rs.getString("apellido_paterno"));
                    medico.setApellido_materno(rs.getString("apellido_materno"));
                    medico.setCedula(rs.getString("cedula"));
                    medico.setEspecialidad(rs.getString("especialidad"));
                    medico.setEstado(rs.getString("estado"));
                    
                    Usuario usuario = new Usuario();
                    usuario.setId_usuario(rs.getInt("id_usuario"));
                    usuario.setNombre(rs.getString("nombre_usuario"));
                    usuario.setContrasenia(rs.getString("contrasenia"));  
                    
                    medico.setUsuario(usuario);
                    
                    return medico;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException("Error al obtener médico.", ex);
        }
        return null;
    }

    /**
     * Cambia el estado del médico a 'inactivo' en la base de datos.
     *
     * @param medico El objeto {@link Medico} que se desea desactivar.
     * @throws PersistenciaException Si ocurre un error al desactivar el médico.
     */
    @Override
    public void desactivarMedico(Medico medico) throws PersistenciaException {
        String comandoSQL = "call desactivar_medico(?);";
        
        try (Connection con = this.conexion.crearConexion();
                CallableStatement cb = con.prepareCall(comandoSQL)) {
            cb.setInt(1, medico.getId_medico());
            
            cb.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException(ex.getMessage(), ex);
        }
    }

    /**
     * Cambia el estado del médico a 'activo' en la base de datos.
     *
     * @param medico El objeto {@link Medico} que se desea activar.
     * @throws PersistenciaException Si ocurre un error al activar el médico.
     */
    @Override
    public void activarMedico(Medico medico) throws PersistenciaException {
        String comandoSQL = "call activar_medico(?);";
        
        try (Connection con = this.conexion.crearConexion();
                CallableStatement cb = con.prepareCall(comandoSQL)) {
            cb.setInt(1, medico.getId_medico());
            
            cb.execute();
        } catch (SQLException ex) {
            Logger.getLogger(MedicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException(ex.getMessage(), ex);
        }
    }
    
    /**
     * Obtiene todas las especialidades disponibles de los médicos.
     *
     * @return Una lista de cadenas con las especialidades de los médicos.
     * @throws PersistenciaException Si ocurre un error al obtener las
     * especialidades.
     */
    @Override
    public List<String> obtenerEspecialidades() throws PersistenciaException {
        List<String> especialidades = new ArrayList<>();
        String consultaSQL = "select distinct especialidad from medicos order by especialidad";

        try (Connection con = conexion.crearConexion(); 
                PreparedStatement ps = con.prepareStatement(consultaSQL)) {
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                especialidades.add(rs.getString("especialidad"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(MedicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException("Error al obtener especialidades.", ex);
        }
        return especialidades;
    }
    
    /**
     * Obtiene los médicos que pertenecen a una especialidad específica.
     *
     * @param especialidad La especialidad de los médicos que se desean obtener.
     * @return Una lista de nombres de médicos que pertenecen a la especialidad
     * solicitada.
     * @throws PersistenciaException Si ocurre un error al obtener los médicos
     * por especialidad.
     */
    @Override
    public List<Medico> obtenerMedicosPorEspecialidad(String especialidad) throws PersistenciaException {
        List<Medico> medicos = new ArrayList<>();
        String consultaSQL = "SELECT id_medico, nombre, apellido_paterno, apellido_materno FROM medicos WHERE especialidad = ? ORDER BY nombre";

        try (Connection con = conexion.crearConexion(); 
                PreparedStatement ps = con.prepareStatement(consultaSQL)) {
            ps.setString(1, especialidad);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Medico medico = new Medico();
                    medico.setId_medico(rs.getInt("id_medico"));
                    medico.setNombre(rs.getString("nombre"));
                    medico.setApellido_paterno(rs.getString("apellido_paterno"));
                    medico.setApellido_materno(rs.getString("apellido_materno")); // Puede ser null

                    medicos.add(medico);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(MedicoDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException("Error al obtener médicos.", ex);
        }
        return medicos;
    }
    
}
