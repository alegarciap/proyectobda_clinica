/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import static DAO.PacienteDAO.getMD5;
import conexion.IConexion;
import entidades.Usuario;
import excepciones.PersistenciaException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Implementación de la interfaz IUsuarioDAO. Esta clase proporciona métodos
 * para interactuar con la base de datos con respecto a los usuarios, como
 * iniciar sesión, obtener el tipo de usuario y obtener el ID del usuario.
 *
 * @author Alejandra García Preciado
 */
public class UsuarioDAO implements IUsuarioDAO {
    
    IConexion conexion;

    /**
     * Constructor de la clase UsuarioDAO.
     *
     * @param conexion La conexión a la base de datos.
     */
    public UsuarioDAO(IConexion conexion) {
        this.conexion = conexion;
    }
    
    /**
     * Verifica las credenciales de inicio de sesión de un usuario.
     *
     * @param usuario El objeto Usuario que contiene el nombre de usuario y la
     * contraseña.
     * @return true si el inicio de sesión es exitoso, false de lo contrario.
     * @throws PersistenciaException Si ocurre un error al consultar la base de
     * datos.
     */
    @Override
    public boolean iniciarSesion(Usuario usuario) throws PersistenciaException {
        String comandoSQL = "select * from usuarios where nombre = ?;";
        
        try (Connection con = conexion.crearConexion(); 
                PreparedStatement ps = con.prepareStatement(comandoSQL)) {
            ps.setString(1, usuario.getNombre());
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                String contrasenia = rs.getString("contrasenia");
                String contraseniaEncriptada = getMD5(usuario.getContrasenia());
                
                if (contrasenia.equals(contraseniaEncriptada)) {
                    return true; // inicio de sesión existoso
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException("Error: No se pudo iniciar sesión.", ex);
        }
        return false;
    }
    
    /**
     * Obtiene el tipo de usuario a partir de su ID.
     *
     * @param id_usuario El ID del usuario.
     * @return El tipo de usuario, médico o paciente.
     * @throws PersistenciaException Si ocurre un error al consultar la base de
     * datos.
     */
    @Override
    public String obtenerTipoUsuario(int id_usuario) throws PersistenciaException {
        String tipo_usuario= "";
        String comandoSQL = "call obtener_tipo_usuario(?, ?);";
        
        try (Connection con = this.conexion.crearConexion();
                CallableStatement cs = con.prepareCall(comandoSQL)) {
            cs.setInt(1, id_usuario);
            cs.registerOutParameter(2, Types.VARCHAR);
            
            cs.execute();
            
            tipo_usuario = cs.getString(2);
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException("Error: No se pudo obtener el tipo de usuario.", ex);
        }
        return tipo_usuario;
    }
    
    /**
     * Obtiene el ID de un usuario basado en su nombre de usuario.
     *
     * @param nombre_usuario El nombre de usuario.
     * @return El ID del usuario.
     * @throws PersistenciaException Si ocurre un error al consultar la base de
     * datos.
     */
    @Override
    public int obtenerIdUsuario(String nombre_usuario) throws PersistenciaException {
        String comandoSQL = "select id_usuario from usuarios where nombre = ?;";

        try (Connection con = conexion.crearConexion(); 
                PreparedStatement ps = con.prepareStatement(comandoSQL)) {
            ps.setString(1, nombre_usuario);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("id_usuario"); 
            } else {
                throw new PersistenciaException("Usuario no encontrado.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            throw new PersistenciaException("Error al obtener el ID del usuario.", ex);
        }
    }
    
}
