/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAO;

import entidades.Usuario;
import excepciones.PersistenciaException;

/**
 * Interfaz que define las operaciones para la gestión de usuarios en la base de
 * datos. Proporciona métodos para iniciar sesión, obtener el tipo de usuario y
 * obtener el ID de un usuario.
 *
 * @author Alejandra García Preciado
 */
public interface IUsuarioDAO {

    /**
     * Inicia sesión verificando las credenciales del usuario.
     *
     * @param usuario El objeto Usuario que contiene las credenciales a
     * verificar.
     * @return true si el inicio de sesión es exitoso, false de lo contrario.
     * @throws PersistenciaException Si ocurre un error durante la consulta en
     * la base de datos.
     */
    public boolean iniciarSesion(Usuario usuario) throws PersistenciaException;

    /**
     * Obtiene el tipo de usuario basado en su ID.
     *
     * @param id_usuario El ID del usuario.
     * @return El tipo de usuario (médico o paciente).
     * @throws PersistenciaException Si ocurre un error durante la consulta en
     * la base de datos.
     */
    public String obtenerTipoUsuario(int id_usuario) throws PersistenciaException;

    /**
     * Obtiene el ID de un usuario basado en su nombre de usuario.
     *
     * @param nombre_usuario El nombre de usuario.
     * @return El ID del usuario.
     * @throws PersistenciaException Si ocurre un error durante la consulta en
     * la base de datos.
     */
    public int obtenerIdUsuario(String nombre_usuario) throws PersistenciaException;

}
