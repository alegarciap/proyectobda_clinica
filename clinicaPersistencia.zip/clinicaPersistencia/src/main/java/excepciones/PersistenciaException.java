/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excepciones;

/**
 * Excepción personalizada para manejar errores relacionados con la persistencia
 * de datos. Esta clase extiende {@link Exception} y permite proporcionar un
 * mensaje de error específico o una causa que lo originó.
 *
 * <p>
 * La clase {@code PersistenciaException} puede ser utilizada en situaciones
 * donde ocurra un fallo durante operaciones de persistencia.</p>
 *
 * @author Alejandra García Preciado
 */
public class PersistenciaException extends Exception{
    
    public PersistenciaException(String message) {
        super(message);
    }

    public PersistenciaException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
