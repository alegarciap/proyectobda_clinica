/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package GUI;

/**
 * Clase principal que inicia la aplicación. Su función es crear una instancia
 * del formulario de inicio de sesión y mostrarla.
 *
 * @author Alejandra García Preciado
 */
public class Inicio {

    /**
     * Método principal que actúa como punto de entrada de la aplicación. Crea
     * una instancia de {@link LoginForm} y la muestra en pantalla.
     *
     * @param args Argumentos de la línea de comandos.
     */
    public static void main(String[] args) {
        LoginForm login = new LoginForm();
        login.setVisible(true);
    }
    
}
